package uts_00000113854_JesselynVaniaAngelie

import java.util.Scanner

fun main(){
    val scanner = Scanner(System.`in`)
    println("=== UMN CATERING MANAGEMENT SYSTEM ===")

    val m1: CateringMenu = FoodMenu("Nasi Goreng Spesial", "nsg01", 25000.0)
    val m2: CateringMenu = FoodMenu("Ayam Bakar Madu", "aym02", 35000.0)
    val m3: CateringMenu = DrinkMenu("Es Teh Lemon", "lem01", 8000.0)

    val menus: List<CateringMenu> = listOf(m1, m2, m3)

    println()
    println("--- CUSTOMER DATA INPUT ---")
    println("Customer Name: ")
    val name = scanner.nextLine()
    println("Phone Number: ")
    val phoneNumber = scanner.nextLine()
    println("Delivery Address: ")
    val deliveryAddress = scanner.nextLine()

    val customer = Customer(name, phoneNumber, deliveryAddress)
    val order = CateringOrder(customer)

    var running : Boolean = true
    while(running){
        println("--- MENU CATALOG ---")
        menus.forEachIndexed { index, menu ->
            println("${index + 1}. ${menu.name}")
        }
        println("0. [FINISH & CHECKOUT]")
        println("Select menu number: ")
        val choose = scanner.nextInt()
        scanner.nextLine()
        when (choose){
            1 -> {
                println("Masukkan jumlah pesanan: ")
                val quan = scanner.nextInt()
                order.addMenuToOrder(m1, quan)
                println("Berhasil menambahkan pesanan!")
            }
            2 -> {
                println("Masukkan jumlah pesanan: ")
                val quan = scanner.nextInt()
                order.addMenuToOrder(m2, quan)
                println("Berhasil menambahkan pesanan!")
            }
            3 -> {
                println("Masukkan jumlah pesanan: ")
                val quan = scanner.nextInt()
                order.addMenuToOrder(m3, quan)
                println("Berhasil menambahkan pesanan!")
            }
            0 -> {
                running = false
                println("Memproses checkout")
            }
            else -> {
                println("Input invalid")
            }
        }
    }
    println()
    order.status = OrderStatus.COOKING
    order.printInvoice()

    scanner.close()
}