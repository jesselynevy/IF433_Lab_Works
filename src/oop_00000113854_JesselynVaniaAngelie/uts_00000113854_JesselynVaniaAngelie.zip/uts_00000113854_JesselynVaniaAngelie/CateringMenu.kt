package uts_00000113854_JesselynVaniaAngelie

abstract class CateringMenu(val name: String, menuCode: String, basePrice: Double): IBillable{
    var menuCode: String = ""
        set(value){
            field = value.uppercase()
        }
        get() = "UMN-$field"

    var basePrice: Double =0.0
        set(value){
        if(value >= 0.0){
            field = value
        } else{
            field = 0.0
            println("[Error] Invaid Input!")
        }
    }

    init {
        this.basePrice = basePrice
        this.menuCode = menuCode
    }

    abstract override fun calculateSubtotal(quantity: Int): Double
    abstract override fun printMenuDetails(quantity: Int)
}