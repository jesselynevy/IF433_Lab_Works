package uts_00000113854_JesselynVaniaAngelie

class DrinkMenu(name: String, menuCode: String, basePrice: Double): CateringMenu(
    name, menuCode, basePrice
) {
    var isLargeSize: Boolean = false
    override fun calculateSubtotal(quantity: Int): Double {
        if(isLargeSize){
            return (basePrice + 5000.0) *quantity
        } else{
            return basePrice * quantity
        }
    }

    override fun printMenuDetails(quantity: Int) {
        println("Drink Info")
        println()
        println("Drink Info: $name - $menuCode")
        println("Size: ${checkLarge(isLargeSize)}")
        println("Quantity: $quantity")
        println("Subtotal: ${calculateSubtotal(quantity)}")
    }
    fun checkLarge(isLarge: Boolean) = if(isLarge) "Large" else "Normal"
}